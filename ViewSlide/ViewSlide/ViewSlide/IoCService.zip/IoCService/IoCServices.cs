﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace ViewSlide.IoCService
{
    public class IoCServices
    {
        private Dictionary<Type, IValueModel> _registrations;

        public IoCServices() 
        {
            _registrations = new Dictionary<Type, IValueModel>();
        }

        public void RegisterTransient<T>()
        {
            Func<object> func = () => { return CreateInstance(typeof(T)); };

            _registrations.Add(typeof(T), new ValueModel_Transient(func));
        }

        public void RegisterSingleton<T>()
        {
            object instance = CreateInstance(typeof(T));

            _registrations.Add(typeof(T), new ValueModel_Singleton(instance));
        }

        public void RegisterSingleton(object instance)
        {
            _registrations.Add(instance.GetType(), new ValueModel_Singleton(instance));
        }

        public T GetService<T>()
        {
            return (T)_registrations[typeof(T)].GetValue();
        }

        private object CreateInstance(Type type)
        {
            ConstructorInfo ctor = type.GetConstructors().Single();

            IEnumerable<Type> parameterTypes = ctor.GetParameters().Select(p => p.ParameterType);

            object[] dependencies = parameterTypes.Select(t => this.Resolve(t)).ToArray();

            object instance = Activator.CreateInstance(type, dependencies);

            return instance;
        }

        private object Resolve(Type type)
        {
            if (_registrations.TryGetValue(type, out IValueModel val))
            {
                return val.GetValue();
            }
            else if (!type.IsAbstract)
            {
                return CreateInstance(type);
            }
            else
            {
                throw new InvalidOperationException("No registration for " + type);
            }
        }
    }
}
