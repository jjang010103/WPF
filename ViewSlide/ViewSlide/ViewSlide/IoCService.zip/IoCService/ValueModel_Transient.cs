﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ViewSlide.IoCService
{
    public class ValueModel_Transient : IValueModel
    {
        private Func<object> GetObject { get; set; }

        public ValueModel_Transient(Func<object> getObject)
        {
            GetObject = getObject;
        }

        public object GetValue()
        {
            return GetObject();
        }
    }
}
