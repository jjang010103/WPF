﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ViewSlide.IoCService
{
    public class ValueModel_Singleton : IValueModel
    {
        private object Value { get; set; }

        public ValueModel_Singleton(object value) 
        {
            Value = value;
        }

        public object GetValue()
        {
            return Value;
        }
    }
}
